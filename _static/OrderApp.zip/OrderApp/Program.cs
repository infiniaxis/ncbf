﻿using System;

namespace OrderApp
{
    public class Program
    {
        public static void Main(string[] args)
        {
            string response = "";
            OrderGluer og = new OrderGluer();
            do
            {
                Console.Write("1. Bubble Tea; 2. Black Tea; or 'quit': ");
                response = Console.ReadLine();
                if (response != "quit")
                {
                    og.Add(Convert.ToInt32(response), 1);
                }
            } while (response != "quit");
            string filename = "data.txt";
            og.Save(filename);
        }
    }
}