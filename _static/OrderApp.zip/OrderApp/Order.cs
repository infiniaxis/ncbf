﻿using System;
using System.Collections.Generic;

namespace OrderApp
{
    public class Order
    {
        public int Id { set; get; }
        public string Item { set; get; }
        public int Quantity { set; get; }
        public DateTime Date { set; get; }
        public int Subtotal { set; get; }
    }

    public class OrderGluer
    {
        public List<Order> orders = new List<Order>();

        public void Add(int response, int quantity)
        {
            Order o = new Order();
            if (response == 1)
                o.Item = "Bubble Tea";
            else
                o.Item = "Black Tea";
            o.Quantity = quantity;
            o.Date = DateTime.Now;
            o.Subtotal = 30;
            o.Id = orders.Count + 1;
            orders.Add(o);
        }

        public void Save(string filename)
        {
            System.IO.FileStream fs = new System.IO.FileStream(filename, System.IO.FileMode.Create);
            using (System.IO.StreamWriter writer = new System.IO.StreamWriter(fs))
            {
                for (int i = 0; i < orders.Count; i++)
                {
                    string row = orders[i].Id + "," + orders[i].Item + "," + orders[i].Quantity + "," + orders[i].Date.ToLocalTime() + "," + orders[i].Subtotal;
                    writer.WriteLine(row);
                }
            }
        }
    }
}
